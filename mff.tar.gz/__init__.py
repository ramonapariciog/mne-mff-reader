"""MFF EGI module."""

# Author: Ramon Aparicio

from .egimff import read_egi_mff, _combine_triggers